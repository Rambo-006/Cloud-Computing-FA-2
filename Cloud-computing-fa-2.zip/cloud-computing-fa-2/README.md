# Cloud Computing FA-2

A Pen created on CodePen.

Original URL: [https://codepen.io/Rambo-006/pen/xbZzONM](https://codepen.io/Rambo-006/pen/xbZzONM).

Hosting a personal portfolio